let username;

document.getElementById("mySubmit").onclick = function(){
    username = document.getElementById("myText").value;
    document.getElementById("myH2").textContent = `Hello ${username} welcome to EduBridge`
    window.alert('This page is for student');
}    

let total = 0;

function addToCart(book, price) {

    let cart = document.getElementById("cart");

    let item = document.createElement("li");

    item.textContent = book + " - R" + price;

    cart.appendChild(item);

    total += price;

    document.getElementById("total").textContent =
    "Total: R" + total;
}



function clearCart() {

    document.getElementById("total").textContent =
    "Total: R0";

    alert("Cart cleared successfully!");

    document.getElementById("cart").innerHTML = "";

    total = 0;
}

function addReview() {
    
    let review =
    document.getElementById("review").value;
     
    let li = document.createElement("li");
    li.textContent = review;
    
    document.getElementById("reviews").appendChild(li);
}
 
